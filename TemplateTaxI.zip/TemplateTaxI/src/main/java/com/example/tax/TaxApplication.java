package com.example.tax;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class TaxApplication {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter tax Type");
//		String taxType=s.next();
//		System.out.println("Enter taxable Amount");
//		int taxableAmount=s.nextInt();
//		 Tax propertyTax =(Tax) context.getBean("propertyTax");
//		 Tax incomeTax =(Tax) context.getBean("incomeTax");
//		 if(taxType.equalsIgnoreCase("IncomeTax")) {
//			 incomeTax.setTaxableAmount(taxableAmount);
//			 incomeTax.calculateTaxAmount();
//			// System.out.println(incomeTax.getTaxAmount());
//			 incomeTax.payTax();
//		 }
//		 else if(taxType.equalsIgnoreCase("propertyTax")){
//			 propertyTax.setTaxableAmount(taxableAmount);
//			 propertyTax.calculateTaxAmount();
//			// System.out.println(propertyTax.getTaxAmount());
//			 propertyTax.payTax();
//		 }
		

	}

}
