package com.example.tax;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class TaxApplication {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Scanner s = new Scanner(System.in);
//		System.out.println("Enter tax Type");
		String taxType = s.next();
		switch (taxType) {
		case "property": {
			Tax propertyTax = (Tax) context.getBean("propertyTax");
			break;
		}
		case "income": {
			Tax incomeTax = (Tax) context.getBean("incomeTax");
			break;
		}

		}

	}
}
