package com.example.tax;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class TaxApplication {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Scanner s = new Scanner(System.in);
//		System.out.println("Enter tax Type");
		
		while (true) {
			System.out.println("Please select which tax you want to pay: \n1. Income \n2. Property\n3. Exit");
			int taxChoice = s.nextInt();
			String property = "";
			switch (taxChoice) {
			case 1: {
				property = "incomeTax";
				break;
			}
			case 2: {
				property = "propertyTax";

				break;
			}
			default: {
				return;
			}
				
			}
			Tax tax = (Tax) context.getBean(property);
			System.out.println(tax.getTaxType());

		}

	}
}
